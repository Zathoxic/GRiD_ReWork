<?php
    require 'inc/header.php';
include_once("inc/class.TemplatePower.inc.php");

$tpl = new TemplatePower( "tpl/projecten.tpl" );
$tpl->prepare();
$tpl->printToScreen();
?>
